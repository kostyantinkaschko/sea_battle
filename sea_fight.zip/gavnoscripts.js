let bigShipLocation, 
    leftBigShipLocation,
    rightBigShipLocation,
    bigShipAttack = false,
    leftCellOfBigShipAttack = false,
    rightCellOfBigShipAttack = false,
    player_error = 10,
    gameStop = false,
    totalShots = 0,
    successfulShots = 0,
    missedShots = 0,
    attackedCells,
    enteredNumbers = 0,
    gridBigShip = "grid: " + leftBigShipLocation + " " + bigShipLocation + " " + rightBigShipLocation

function rand(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min
}
let bigShipOrientation = rand(0, 1);

if (bigShipOrientation === 0) {
    bigShipOrientation = "Horizontal"
} else if (bigShipOrientation === 1) {
    bigShipOrientation = "Vertical"
}
if (bigShipOrientation === "Horizontal") {
    bigShipLocation = rand(2, 24);
    while (bigShipLocation % 5 === 0 || (bigShipLocation + 1) % 5 === 0) {
        bigShipLocation = rand(2, 24);
    }
    leftBigShipLocation = bigShipLocation - 1;
    rightBigShipLocation = bigShipLocation + 1;
} else if (bigShipOrientation === "Vertical") { // Vertical
    bigShipLocation = rand(6, 20);
    while (bigShipLocation % 5 === 0 || (bigShipLocation + 5) > 25) {
        bigShipLocation = rand(6, 20);
    }
    leftBigShipLocation = bigShipLocation - 5;
    rightBigShipLocation = bigShipLocation + 5;
}


while (!gameStop) {
    let shoot
    try {
        shoot = prompt("Виберіть комірку 1-25")
        if (shoot === null) {
            gameStop = true
            alert("Гра закінчена.")
            break
        }
        shoot = parseInt(shoot)
        if (isNaN(shoot) || shoot < 1 || shoot > 25) {
            throw new Error("Невірне введення! Введіть число від 1 до 25.")
        }

        let gridPosition = shoot - 1
        let mask = 1 << gridPosition

        if ((enteredNumbers & mask) !== 0) {
            throw new Error("Ви вже стріляли по цій комірці! Виберіть іншу.")
        }

        enteredNumbers |= mask

    } catch (error) {
        alert(error.message + " Ваші спроби:" + player_error)
        continue
    } finally {
        if (shoot == bigShipLocation || shoot == lftBigShipLocation || shoot == rightBigShipLocation) {
            switch (shoot) {
                case bigShipLocation:
                    bigShipAttack = true
                case rightBigShipLocation:
                    rightCellOfBigShipAttack = true;
                case leftBigShipLocation:
                    leftCellOfBigShipAttack = true;
                    break
            }
            player_error++
            successfulShots++
            alert("Ви поцілили по кораблю! Ваші спроби: " + player_error)
            if (bigShipAttack && rightCellOfBigShipAttack && leftCellOfBigShipAttack) {
                gameStop = true
                alert("Вітаємо! Ви виграли!")
            }
        } else {
            player_error--
            missedShots++
            alert("Ви не поцілили у корабель. Ваші спроби: " + player_error)
        }
        if (player_error <= 0) {
            gameStop = true
            alert("Гра закінчена. Ви програли. Успішність атак: " + ((successfulShots / totalShots) * 100).toFixed(2) + "%")
        }
        if (player_error > 20) {
            player_error = 20
        }
    }
}